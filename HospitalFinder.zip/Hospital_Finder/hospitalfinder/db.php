<?php
//connect to database hospitalfinder
$link = mysqli_connect("localhost",'root','','hospitalfinder');
 ?>
